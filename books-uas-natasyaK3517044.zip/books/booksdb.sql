-- phpMyAdmin SQL Dump
-- version 4.8.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 06, 2019 at 05:20 PM
-- Server version: 10.1.37-MariaDB
-- PHP Version: 5.6.39

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `booksdb`
--

-- --------------------------------------------------------

--
-- Table structure for table `books`
--

CREATE TABLE `books` (
  `idbuku` int(11) NOT NULL,
  `judul` varchar(100) DEFAULT NULL,
  `pengarang` varchar(100) DEFAULT NULL,
  `penerbit` varchar(100) DEFAULT NULL,
  `idkategori` int(11) DEFAULT NULL,
  `imgfile` varchar(100) DEFAULT NULL,
  `sinopsis` text,
  `thnterbit` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `books`
--

INSERT INTO `books` (`idbuku`, `judul`, `pengarang`, `penerbit`, `idkategori`, `imgfile`, `sinopsis`, `thnterbit`) VALUES
(31, 'Kata (Tentang Senja yang Kehilangan Langitnya)', 'Rintik Sendu', 'Gagas Media', 35, 'Kata-Rintik-Sedu.jpg', 'Novel ini menceritakan perasaan tiga tokoh utamanya, yaitu Nugraha, Biru dan juga Binta yang saling membelakangi dan pergi. Mereka butuh kata-kata untuk menjelaskan perasaan.\r\n\r\nMereka harus bicara dan berhenti menyembunyikan kata hati serta mencari jawaban dari sebuah perasaan.', 2018),
(32, 'Lima Sekawan: Jo Anak Gelandangan (Cetak Ulang 2018)', 'Enid Blyton', 'Gramedia Pustaka Utama', 1, 'download.jpg', 'George dan Timmy hilang—apakah mereka diculik? Mengapa ada orang yang masuk ke Pondok Kirrin dan mengobrak-abrik ruang kerja Paman Quentin? Lima Sekawan yakin kedua hal itu berhubungan, tapi apa hubungannya? Dan bagaimana mereka dapat memecahkan misteri itu, kalau mereka tinggal bertiga?', 2018),
(33, 'Lima Sekawan: Rahasia Di Pulau Kirrin (Cetak Ulang 2018)', 'Enid Blyton', 'Gramedia Pustaka Utama', 35, 'Lima-Sekawan_Rahasia-di-Pulau-Kirrin-629x1024.jpg', 'Lima Sekawan adalah Julian, Dick, George, Anne, dan—tentu saja—Timmy! Ke mana pun mereka pergi pasti ada petualangan yang seru dan mengasyikkan! RAHASIA DI PULAU KIRRIN Apa yang dikerjakan Paman Quentin di Pulau Kirrin? Dia melarang siapa pun datang ke pulau—bahkan juga Lima Sekawan! Tapi dia tidak sendirian di Pulau Kirrin— ada orang yang mengawasi setiap gerak-geriknya!', 2018),
(34, 'Siapa Takut!', 'Mutiara Sya\'bani', 'Mizan Media Utama', 33, '9786024208011_Komik-Kkpk-Siapa-Takut__w414_hauto.jpg', 'Aisya memang sudah berjanji untuk mulai tidur sendiri malam ini. Namun, Aisya masih takut. Soalnya, tadi malam Aisya mendengar bunyi langkah kaki di\r\nluar kamarnya. Hiiiy .... Oleh Kak Aira, Aisya didorong untuk menjadi lebih berani dengan bantuan resolusi. Apa itu resolusi? Berhasilkah Aisya mengatasi rasa\r\ntakutnya dan menjadi pemberani? Ayo baca kisah Aisya dalam mengatasi rasa takutnya di buku ini! Jangan lewatkan empat cerita seru lainnya, ya!', 2019),
(35, 'Petualangan Tintin: Harta Karun Rackham Merah', 'Herge', ' Gramedia Pustaka Utama', 33, '9786020316833_Petualangan-Tintin_Harta-Karun-Rackham-Merah__w414_hauto.jpg', 'Belum ada sinopsis', 2015),
(36, 'Petualangan Tintin: Laut Merah', 'Herge', 'Gramedia Pustaka Utama', 33, 'petualangan-tintin-laut-merah__w414_hauto.jpg', 'Si tengil Abdallah dikirim ayahnya, Emir Ben Kalish Ezab ke Moulinsart karena di Khemed terjadi kudeta. Tak tahan dengan kelakuan badung anak itu, serta tertarik dengan misteri yang menyelimuti kudeta di Khemed, Tintin dan Kapten Haddock justru pergi ke Khemed. Di sana ternyata mereka menghadapi masalah lebih pelik lagi menyangkut perbudakan! \r\n\r\n*** Kisah PETUALANGAN TINTIN, si wartawan berjambul dan anjingnya, Milo ini telah memukau berbagai kalangan dari segala usia dan diterbitkan dalam 40 bahasa di seluruh dunia. Di negara asalnya, Belgia, Tintin mulai terbit sebagai cerita bergambar dalam majalah Le Petit Vingtieme, sebelum akhirnya tampil sebagai buku sejak tahun 1945. Bisa dibilang PETUALANGAN TINTIN adalah tonggak bersejarah dalam dunia komik internasional. Dalam kisah-kisah petualangan Tintin dan Milo---yang kemudian juga ditemani oleh Kapten Haddock, sang ilmuwan Lakmus, serta si kembar Dupondt---pembaca bukan hanya diajak keliling dunia, tapi juga dibawa menelusuri sejarah serta politik sejak tahun 1940-an sampai 1980-an. Terkesan berat? Tintin justru bisa menjadi bacaan anak-anak yang sangat menarik, karena penuh adengan lucu serta pelayanan moral kebaikan vs. kejahatan yang sangat penting.', 2015),
(37, 'Belajar Fotografi Makanan Untuk Pemula', 'Muharini', 'Mitra Media Nusantara Cv', 1, 'img614__w414_hauto.jpg', 'Ingin media sosial Anda dihiasi foto-foto makanan keren ala-ala food blogger dengan hanya berbekal smartphone atau pocket camera? Tepat jika Anda memilih buku ini.', 2019),
(38, 'Belajar Sendiri Adobe InDesign 2019', 'Jubilee Enterprise', 'Elex Media Komputindo', 1, '9786020495989_Belajar-Sendiri-Adobe-InDesign-2019__w414_hauto.jpg', 'Adobe InDesign memudahkan dan mempercepat proses layout, menata kolom, membuat tabel, meletakkan gambar dan ilustrasi, dan sebagainya untuk tujuan pembuatan majalah, buku, hingga ebook. Maka dari itu, penguasaan Adobe InDesign adalah sebuah kewajiban terlebih karena satu alasan penting lainnya, software ini telah menjadi standar industri untuk offset dan digital printing. \r\n\r\nBuku ini membantu para layouter untuk memahami Adobe InDesign. Pembahasan dimulai dari pengenalan interface, bekerja dengan teks, pembuatan tabel, mengelola dokumen, pewarnaan, dan sebagainya. Diharapkan, pembaca bisa membuat layout secara mandiri. Fitur-fitur utama yang sering digunakan dibahas secara lengkap dan mendalam. Karena berjenis referensi, maka pembaca akan menemukan banyak pengetahuan di balik canggihnya fitur Adobe InDesign. Meskipun membahas Adobe InDesign CC 2019, tapi pengguna versi lawas juga dapat mengikuti bahasan di dalam buku ini.', 2019);

-- --------------------------------------------------------

--
-- Table structure for table `kategori`
--

CREATE TABLE `kategori` (
  `idkategori` int(11) NOT NULL,
  `kategori` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `kategori`
--

INSERT INTO `kategori` (`idkategori`, `kategori`) VALUES
(1, 'Buku Teks'),
(3, 'Skripsi'),
(32, 'Thesis'),
(33, 'Komik'),
(35, 'Novel');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `username` varchar(50) NOT NULL,
  `password` varchar(32) DEFAULT NULL,
  `fullname` varchar(100) DEFAULT NULL,
  `role` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`username`, `password`, `fullname`, `role`) VALUES
('admin', '123', 'Administrator', 'Admin'),
('natasyatr', '2212', 'Natasya T. Ramadhanti', 'Operator');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `books`
--
ALTER TABLE `books`
  ADD PRIMARY KEY (`idbuku`);

--
-- Indexes for table `kategori`
--
ALTER TABLE `kategori`
  ADD PRIMARY KEY (`idkategori`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `books`
--
ALTER TABLE `books`
  MODIFY `idbuku` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=39;

--
-- AUTO_INCREMENT for table `kategori`
--
ALTER TABLE `kategori`
  MODIFY `idkategori` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
