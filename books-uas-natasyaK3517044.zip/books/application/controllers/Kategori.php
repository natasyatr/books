<?php
class Kategori extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}

	// method hapus data buku berdasarkan id
	public function delete($id){
		$this->kategori_model->delKat($id);
		// arahkan ke method 'kategori' di kontroller 'dashboard'
		redirect('dashboard/kategori');
	}

	public function insert(){
		$kategori = $_POST['kategori'];
		$this->kategori_model->insertKategori($kategori);
		redirect('dashboard/kategori');
	}


	// method untuk edit data buku berdasarkan id
	public function edit($id){
		$data['view_kategori'] = $this->kategori_model->getKat($id);

		$data['fullname'] = $_SESSION['fullname'];

		if (empty($data['view_kategori'])) {
			show_404();
		}

		$data['idkategori'] = $data['view_kategori']['idkategori'];
		$data['kategori'] = $data['view_kategori']['kategori'];
		
		$this->load->view('dashboard/header', $data);
        $this->load->view('kategori/edit', $data);
        $this->load->view('dashboard/footer');
	}

	public function update() {
		$idkategori = $_POST['idkategori'];
		$kategori = $_POST['kategori'];
		
		$this->kategori_model->updateKategori($idkategori, $kategori);

		redirect('dashboard/kategori');
	}


	/*// method untuk mencari data buku berdasarkan 'key'
	public function findbooks(){
		
		// baca key dari form cari data
		$key = $_POST['key'];

		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->findBook($key);

		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header');
        $this->load->view('kategori/index', $data);
        $this->load->view('dashboard/footer');
	}*/

}
?>