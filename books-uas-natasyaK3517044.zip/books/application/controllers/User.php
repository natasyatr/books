<?php
class User extends CI_Controller {

	public function __construct(){
		parent::__construct();
		
		// cek keberadaan session 'username'	
		if (!isset($_SESSION['username'])){
			// jika session 'username' blm ada, maka arahkan ke kontroller 'login'
			redirect('login');
		}
	}

	// method hapus data buku berdasarkan id
	public function delete($username){
		$this->user_model->delUser($username);
		// arahkan ke method 'books' di kontroller 'dashboard'
		redirect('dashboard/user');
	}

	public function insert(){
		$username = $_POST['username'];
		$password = $_POST['password'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		$this->user_model->insertUser($username, $password, $fullname, $role);
		redirect('dashboard/user');
	}



	// method untuk edit data buku berdasarkan id
	public function edit($username){
		$data['view_user'] = $this->user_model->getUserProfile($username);

		$data['fullname'] = $_SESSION['fullname'];

		if (empty($data['view_user'])) {
			show_404();
		}

		$data['username'] = $data['view_user']['username'];
		$data['fullname'] = $data['view_user']['fullname'];
		$data['role'] = $data['view_user']['role'];
		$data['password'] = $data['view_user']['password'];

		$this->load->view('dashboard/header', $data);
        $this->load->view('user/edit', $data);
        $this->load->view('dashboard/footer');
	}

	public function update() {
		$username = $_POST['username'];
		$fullname = $_POST['fullname'];
		$role = $_POST['role'];
		$password = $_POST['password'];

		$this->user_model->updateUser($username, $fullname, $password, $role);

		redirect('dashboard/user');
	}






/*	// method untuk mencari data buku berdasarkan 'key'
	public function findbooks(){
		
		// baca key dari form cari data
		$key = $_POST['key'];

		// panggil method findBook() dari model book_model untuk menjalankan query cari data
		$data['book'] = $this->book_model->findBook($key);

		// tampilkan hasil pencarian di view 'dashboard/books'
		$this->load->view('dashboard/header');
        $this->load->view('user/index', $data);
        $this->load->view('dashboard/footer');
	}*/

}
?>