<?php

class User_model extends CI_Model {

	// method untuk membaca data profile user
	public function getUserProfile($username){
		$query = $this->db->get_where('user', array('username' => $username));
		return $query->row_array();
	}

	// method untuk menampilkan data buku
	public function showUser(){
		$query = $this->db->get('user');
		return $query->result_array();
	}

	// method untuk hapus data buku berdasarkan id
	public function delUser($username){
		$this->db->delete('user', array("username" => $username));
	}

	// method untuk insert data buku ke tabel 'books'
	public function insertUser($username, $password, $fullname, $role){
		$data = array(
					"username" => $username,
					"password" => $password,
					"fullname" => $fullname,
					"role" => $role
		);
		$query = $this->db->insert('user', $data);
	}

	// method untuk membaca data kategori buku dari tabel 'kategori'
	public function getUser(){
		$query = $this->db->get('user');
		return $query->result_array();
	}

	public function getRole(){
		$query = $this->db->get('role');
		return $query->result_array();
	}

	public function updateUser($username, $fullname, $password, $role){
		$data = array(
			"fullname" => $fullname,
			"role" => $role,
			"password" => $password
		);
		$this->db->update('user', $data, 'username = "' . $username . '"');
	}

}

?>