
    <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

    <!--<form method="post" action="<?php echo site_url('book/findbooks'); // arahkan form submit ke kontroller 'book/findbooks ?>">
    <input class="form-control form-control-dark" type="text" placeholder="Tambah Kategori" aria-label="Search" name="key" style="border: 1px solid #cccccc; margin-top: 20px;">
    </form>-->

  <form action="<?php echo site_url('dashboard/addKat'); ?>">
    <div class="panel-heading" style="float: right; padding: 15px; size: 40px">
      <button class="btn btn-default" data-toggle="modal" >
        <svg style="width:40px;height:40px" viewBox="0 0 24 24">
        <path fill="#000000" d="M17,13H13V17H11V13H7V11H11V7H13V11H17M19,3H5C3.89,3 3,3.89 3,5V19A2,2 0 0,0 5,21H19A2,2 0 0,0 21,19V5C21,3.89 20.1,3 19,3Z" />
        </svg>
      </button>
    </div>
  </form>

     
      <div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Kategori Buku</h1>
      </div>

      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>ID Kategori</th>
              <th>Kategori</th>
              <th>Opsi</th>
            </tr>
          </thead>
          <tbody>

            <?php 
            // menampilkan data buku
            foreach ($kategori as $kategori_item): 
            ?>

            <tr>
              <td><?php echo $kategori_item['idkategori']?></td> 
              <td><?php echo $kategori_item['kategori']?></td>
              <td><?php echo anchor('kategori/edit/'.$kategori_item['idkategori'], 'Sunting', 'Edit Buku'); ?> | <?php echo anchor('kategori/delete/'.$kategori_item['idkategori'], 'Hapus', 'Hapus Buku'); ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </main>
  